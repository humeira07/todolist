//
//  CustomCell.swift
//  toDoApp
//
//  Created by Humeira on 4/1/19.
//  Copyright © 2019 example. All rights reserved.
//

import UIKit
class CustomCell: UITableViewCell {
    
    @IBOutlet weak var myLabel: UILabel!
    
    @IBOutlet weak var myLabel2: UILabel!
    
    @IBOutlet weak var myImageView: UIImageView!
    
    
}
