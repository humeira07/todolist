//
//  TasksList.swift
//  toDoApp
//
//  Created by Humeira on 4/1/19.
//  Copyright © 2019 example. All rights reserved.
//

import Foundation

struct TasksList {
    var title:String?
    var image:String?
    var date:String?
    
    init(title:String,image:String,date:String) {
        self.title = title
        self.image = image
        self.date = date
    }
}
