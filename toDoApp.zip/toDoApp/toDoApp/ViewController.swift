//
//  ViewController.swift
//  toDoApp
//
//  Created by Humeira on 4/1/19.
//  Copyright © 2019 example. All rights reserved.
//

import UIKit




class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, TaskDelegate {
    
    
    var tasks = [String]()
    var dateData = [String]()
    var images = [String]()
    
    var tasksList:[TasksList] = []
    
    let cellIdentifier = "cell"
//    let vc = SecondViewController(nibName:"SecondViewController",bundle:nil)
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        tableView.delegate = self
        tableView.dataSource = self
        tableView.rowHeight = 70
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "InputVC" {
            let displayVC = segue.destination as! SecondViewController
            displayVC.delegate = self
        }
    }
    
    
    func saveData(title: String, image: String, date: String){
        
//        print("Im in saveData \(title)")
//        tasks.append(title)
//        dateData.append(date)
//        images.append(image)
        tasksList.append(TasksList(title: title, image: image, date: date))
        tableView.reloadData()
    
    }
    
    
    @IBAction func editTasks(_ sender: UIBarButtonItem) {
        tableView.setEditing(!tableView.isEditing, animated: true)
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tasksList.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: CustomCell = self.tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as! CustomCell
//        cell.myLabel.text = tasks[indexPath.row]
//        cell.myLabel2.text = dateData[indexPath.row]
        
        let image:UIImage = UIImage(named: tasksList[indexPath.row].image!)!
        
//        cell.myImageView?.image = image
        cell.myLabel.text = tasksList[indexPath.row].title
        cell.myLabel2.text = tasksList[indexPath.row].date
        cell.myImageView?.image = image

        return cell
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
//            tasks.remove(at: indexPath.row)
//            dateData.remove(at: indexPath.row)
//            images.remove(at: indexPath.row)
            tasksList.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        }
    }
    func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        let tempObject = self.tasksList[sourceIndexPath.row]
        tasksList.remove(at: sourceIndexPath.row)
        tasksList.insert(tempObject, at: destinationIndexPath.row)
            
    }

}

