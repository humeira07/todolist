//
//  SecondViewController.swift
//  toDoApp
//
//  Created by Humeira on 4/1/19.
//  Copyright © 2019 example. All rights reserved.
//

import UIKit


protocol TaskDelegate: NSObjectProtocol {
    func saveData(title : String, image: String, date: String)
}

class SecondViewController: UIViewController {
    var mainViewController: ViewController?
    
    
   // var categoryImages1 = ["rockIt1"]
   // var categoryImages2 = ["rockIt2"]

    
    @IBOutlet weak var titleError: UILabel!
    
    weak var delegate: TaskDelegate?
    
    
    @IBOutlet var categoryButtons: [UIButton]!
    
    @IBOutlet weak var datePicker: UIDatePicker!
    
    @IBOutlet weak var titleLabel: UITextField!
    
    var indexOfSelectedImage = 0
    
    var datePickerString = ""

    override func viewDidLoad() {
        
        super.viewDidLoad()

    }

    
    @IBAction func addTask(_ sender: Any) {
        
        if let delegate = delegate {
            updateTime()
            
            if titleLabel.text! == "" {
                titleError.text = "the title is required"
                titleError.textColor = .red
            }
            
            else {
                
                delegate.saveData(title: titleLabel.text!, image: "rockIt2", date: datePickerString)
                self.perfomeSegueToReturnBack()
            }

        }
    }
    
    
    @IBAction func chooseCategory(_ sender: Any) {
        if let buttonNumber = categoryButtons.firstIndex(of: sender as! UIButton){
            indexOfSelectedImage = buttonNumber
            

            updateButtons(index: buttonNumber)
            
        }
            
    }
    
    func updateTime(){
        let timeFormatter = DateFormatter()
        timeFormatter.timeStyle = DateFormatter.Style.long
        datePickerString = timeFormatter.string(from: datePicker.date)
    }
    
    func updateButtons(index: Int){
        for i in categoryButtons.indices {
            let image = UIImage(named: "rockIt1")
            categoryButtons[i].setImage(image, for: .normal)
        }
        
        
        let image = UIImage(named: "rockIt2")
        categoryButtons[index].setImage(image, for: .normal)
        
        
    }
    
    
    
    
    


}

extension UIViewController {
    func perfomeSegueToReturnBack(){
        if let nav = self.navigationController {
            nav.popViewController(animated: true)
        } else {
            self.dismiss(animated: true, completion: nil)
        }
    }
}
